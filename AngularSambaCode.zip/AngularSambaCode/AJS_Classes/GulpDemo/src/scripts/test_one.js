/*
    Creating the Function
 */
function my_fun(){
    return "I m from My Function !";
}