/*
    Creating the Function
 */
 function my_fun() {
     return "I am, from my_fun !!!!";
 }