/*
    Creating the Function
 */
function my_fun(){
    return "I m from My Function !";
}
/*
    Creating the Function
 */
 function my_fun() {
     return "I am, from my_fun !!!!";
 }