function my_class(arg1,arg2) {
    this.fun_one = function () {
      return arg1;
    };

    this.fun_two = function () {
        return arg2;
    };
}