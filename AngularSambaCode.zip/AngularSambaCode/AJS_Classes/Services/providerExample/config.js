app.config(config);
function config(my_serviceProvider) {
    my_serviceProvider.db_password="root_two";
}