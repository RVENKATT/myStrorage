/*
app.value("my_service","First Value");
app.value("my_service","Second Value");*/


app.constant("my_service","First Value");
app.constant("my_service","Second Value");