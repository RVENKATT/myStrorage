var class_one = function () {



    //Create the Function


    this.fun_one = function () {
        return "I am from Test File !";
    };
};