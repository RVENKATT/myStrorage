var class_two = Object();

class_two.fun_one = function () {
  return "I am from Test File !";
};