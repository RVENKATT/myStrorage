﻿(function () {
    "use strict";
    app.controller("chart", chart);
    function chart($scope) {
        $scope.chart = "Use d3js with charts and graphs";
    }
})();