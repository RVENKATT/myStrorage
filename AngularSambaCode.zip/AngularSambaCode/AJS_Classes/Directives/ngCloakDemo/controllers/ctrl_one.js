(function () {
    "use strict";

    app.controller("ctrl_one",ctrl_one);
    function ctrl_one($scope) {
        $scope.var_one = "I am from controller One !";
    }
})();